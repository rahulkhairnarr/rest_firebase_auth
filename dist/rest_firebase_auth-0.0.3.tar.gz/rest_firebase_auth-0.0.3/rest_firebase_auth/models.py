# -*- coding: utf-8 -*-
"""
Models for storing the uid of authenticating firebase users and relating them
to the local AUTH_USER_MODEL model.
Original Github: https://github.com/garyburgmann/drf-firebase-auth
Author: Rahul Khairnar
Email: rahulkhairnar@gmail.com
Location: Silvassa, India
Last update: 2020-06-13
"""
from django.db import models
from django.conf import settings
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager



class FirebaseUser(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        null=False,
        related_name='firebase_user',
        related_query_name='firebase_user',
    )
    uid = models.CharField(max_length=191, null=False,)


class FirebaseUserProvider(models.Model):
    firebase_user = models.ForeignKey(
        'FirebaseUser',
        on_delete=models.CASCADE,
        null=False,
        related_name='provider',
        related_query_name='provider',
    )
    uid = models.CharField(max_length=191, null=False,)
    provider_id = models.CharField(max_length=50, null=False,)


class MyAccountManager(BaseUserManager):
    def create_user(self,uid,username,password=None):
        if not uid:
            raise ValueError("Users must have an uid")

        user  = self.model(
                uid=uid
            )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, uid,username, password):
        user  = self.create_user(
                password=password,
                uid=uid,
                username=username
            )
        user.is_admin = True
        user.is_staff = True
        user.is_superuser = True
        user.save(using=self._db)
        return user


class Account(AbstractBaseUser):
    uid = models.CharField(max_length=60, unique=True)
    email = models.EmailField(verbose_name="email", max_length=60, unique=True)
    username = models.CharField(max_length=30, unique=True)
    phone = models.CharField(max_length=30, unique=True)
    date_joined = models.DateTimeField(verbose_name='date joined', auto_now_add=True)
    last_login = models.DateTimeField(verbose_name='last login', auto_now=True)
    is_admin = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    
    USERNAME_FIELD = 'uid'
    REQUIRED_FIELDS = ['username', ]
    
    objects = MyAccountManager()

    def __str__(self):
        return self.uid

    def has_perm(self, perm, obj=None):
        return self.is_admin

    def has_module_perms(self, app_label):
        return True
