# -*- coding: utf-8 -*-

__title__ = 'rest_firebase_auth'
__version__ = '0.0.2'
__author__ = 'Rahul Khairnar'
__license__ = 'MIT'
__copyright__ = 'Copyright 2019 Rahul Khairnar'

# Version synonym
VERSION = __version__
